#!/bin/bash
# use the water shader file

echo "colorMap Mars.cpt" >share/SARndbox-2.8/Control.fifo


